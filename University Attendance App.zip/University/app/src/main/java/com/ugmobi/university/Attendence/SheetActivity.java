package com.ugmobi.university.Attendence;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import com.google.common.collect.Table;
import com.ugmobi.university.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;
public class SheetActivity extends AppCompatActivity implements EasyPermissions.PermissionCallbacks {
    TextView selectedatedisplay;
    String choicedate;
    Integer cid;
    String classname, subjectname;
    Dialog dialog;
    EditText department;
    EditText subject;
    int DAY_IN_MONTH;

    public void openExportDialogur() {
        dialog = new Dialog(this);
        dialog.setContentView(R.layout.export_dialogue);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Window window = dialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        department = dialog.findViewById(R.id.enterdepartment);
        subject = dialog.findViewById(R.id.entersubject);
        department.setText(classname);
        subject.setText(subjectname);
        Button cancel = dialog.findViewById(R.id.cancel);
        Button exportpdf = dialog.findViewById(R.id.sharepdf);
        Button exportcsv = dialog.findViewById(R.id.exportcsv);
        Button showcalanser = dialog.findViewById(R.id.selectdate);
        selectedatedisplay = dialog.findViewById(R.id.selectdatedisplay);

        cancel.setOnClickListener(view -> dialog.dismiss());

        exportpdf.setOnClickListener(view -> {
            if (selectedatedisplay.getText().toString().length() > 4) {
                Toast.makeText(getApplicationContext(), "Sharing...", Toast.LENGTH_SHORT).show();
                Handler handler = new Handler();
                handler.postDelayed(this::Sharepdf, 5000);
            } else {
                Toast.makeText(getApplicationContext(), "Plz Fill Details To Export", Toast.LENGTH_SHORT).show();
            }
        });
        exportcsv.setOnClickListener(view -> {
            Toast.makeText(getApplicationContext(), "Sharing...", Toast.LENGTH_SHORT).show();
            Handler handler = new Handler();
            handler.postDelayed(this::ShareCSV, 3000);

        });
        showcalanser.setOnClickListener(view -> showCalander());
        dialog.show();
    }
    File file = new File(String.valueOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS + "/attaindanceReport.csv")));
    public MyCalander calander;
    TextView displaytext;
    String path = (String.valueOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS + "/StudentData.pdf")));
    ImageButton convert;
    TableLayout tableLayout;
    float[] columnwidth = {140, 50, 70, 80, 80, 50};
    Table table;
    String nameh = "Name";
    String RollNoh = "Roll No";
    String Dateh = "Date";
    String Statush = "Status";
    String Departmenth = "Department";
    String Subjecth = "Subject";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sheet);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        tableLayout = findViewById(R.id.tablelayout);
        convert = findViewById(R.id.convert);
        convert.setVisibility(View.VISIBLE);
        TextView title = toolbar.findViewById(R.id.title_toolbar);
        TextView subtitle = toolbar.findViewById(R.id.subtitle_toolbar);
        ImageButton back = findViewById(R.id.back);
        ImageButton save = findViewById(R.id.save);
        displaytext = findViewById(R.id.selectdatedisplay);
        save.setVisibility(View.INVISIBLE);
        title.setText("Analize Attendance Sheet");
        subtitle.setVisibility(View.INVISIBLE);
        loadtargetlist();
        convert.setOnClickListener(v -> {
            if (EasyPermissions.hasPermissions(SheetActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                openExportDialogur();

            } else {
                EasyPermissions.requestPermissions(SheetActivity.this,
                        "App need Files and Media Permission to save and share PDF and CSV file.",
                        101,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
        });

        back.setOnClickListener(v -> SheetActivity.this.onBackPressed());
        showTable();
    }

    private void showTable() {
        DbHelper dbHelper = new DbHelper(this);
        long[] idArray = getIntent().getLongArrayExtra("idArray");
        int[] rollArray = getIntent().getIntArrayExtra("rollArray");
        String[] nameArray = getIntent().getStringArrayExtra("nameArray");
        String month = getIntent().getStringExtra("month");

        DAY_IN_MONTH = getDayInMonth(month);

        int rowSize = idArray.length + 1;

        TableRow[] rows = new TableRow[rowSize];
        TextView[] roll_tvs = new TextView[rowSize];
        TextView[] name_tvs = new TextView[rowSize];
        TextView[][] status_tvs = new TextView[rowSize][DAY_IN_MONTH + 1];

        for (int i = 0; i < rowSize; i++) {
            roll_tvs[i] = new TextView(this);
            name_tvs[i] = new TextView(this);
            for (int j = 1; j <= DAY_IN_MONTH; j++) {
                status_tvs[i][j] = new TextView(this);
            }
        }

        roll_tvs[0].setText("Roll");
        roll_tvs[0].setTypeface(roll_tvs[0].getTypeface(), Typeface.BOLD);

        name_tvs[0].setText("Name");
        name_tvs[0].setTypeface(name_tvs[0].getTypeface(),Typeface.BOLD);
        for (int i = 1; i <= DAY_IN_MONTH; i++) {
            status_tvs[0][i].setText(String.valueOf(i));
            status_tvs[0][i].setTypeface(status_tvs[0][i].getTypeface(), Typeface.BOLD);
        }

        for (int i = 1; i < rowSize; i++) {
            roll_tvs[i].setText(String.valueOf(rollArray[i - 1]));//
            name_tvs[i].setText(String.valueOf(nameArray[i -1]));
            for (int j = 1; j <= DAY_IN_MONTH; j++) {
                String day = String.valueOf(j);
                if (day.length() == 1) day = "0" + day;
                String date = day + "." + month;
                String status = dbHelper.getStatus(idArray[i - 1], date);
                status_tvs[i][j].setText(status);
            }

        }
        for (int i = 0; i < rowSize; i++) {

            rows[i] = new TableRow(this);

            if (i % 2 == 0)

                rows[i].setBackgroundColor(Color.parseColor("#EEEEEE"));
            else
                rows[i].setBackgroundColor(Color.parseColor("#E4E4E4"));

            roll_tvs[i].setPadding(16, 16, 20, 16);
            name_tvs[i].setPadding(16,16,20,16);
            rows[i].addView(roll_tvs[i]);
            rows[i].addView(name_tvs[i]);

            for (int j = 1; j <= DAY_IN_MONTH; j++) {
                status_tvs[i][j].setPadding(16, 16, 16, 16);
                rows[i].addView(status_tvs[i][j]);

            }
            tableLayout.addView(rows[i]);
        }
        tableLayout.setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
    }

    private int getDayInMonth(String month) {
        int monthIndex = Integer.parseInt(month.substring(0, 2)) - 1;
        int year = Integer.parseInt(month.substring(3));

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MONTH, monthIndex);
        calendar.set(Calendar.YEAR, year);

        return calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
    }



    private void showCalander() {

        calander = new MyCalander();
        calander.show(getSupportFragmentManager(), "");
        calander.setOnCalanderOkClickListner(this::onCalanderOkListner);
    }
    private void onCalanderOkListner(int year, int month, int day) {
        calander.setDate(year, month, day);
        selectedatedisplay.setText(calander.getDate());

    }
    private void loadtargetlist() {
        SharedPreferences sharedPref = getApplication().getSharedPreferences("targetlistshow", Context.MODE_PRIVATE);
        cid = sharedPref.getInt("search", -1);
        classname = sharedPref.getString("department", "");
        subjectname = sharedPref.getString("subject", "");

    }
    private void Sharepdf() {
        Uri uri = FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getPackageName() + ".provider", new File(path));
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/pdf");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Student Data");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        startActivity(Intent.createChooser(intent, "Share File With"));
    }
    private void ShareCSV() {
        Uri uri = FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getPackageName() + ".provider", file);
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Student Data");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        startActivity(Intent.createChooser(intent, "Share File With"));
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults,
                this);
    }
    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        switch (requestCode) {
            case 101:
                openExportDialogur();
                break;
        }
    }
    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            new AppSettingsDialog.Builder(SheetActivity.this).build().show();
        } else {
            Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
        }
    }
}