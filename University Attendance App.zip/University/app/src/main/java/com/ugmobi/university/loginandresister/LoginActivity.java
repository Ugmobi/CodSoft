package com.ugmobi.university.loginandresister;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.ugmobi.university.Admin.AdminDashboard;
import com.ugmobi.university.Admin.AdminLogin;
import com.ugmobi.university.R;
import com.ugmobi.university.Staf.Dashboard;
import com.ugmobi.university.Student.StudentDashboard;

public class LoginActivity extends AppCompatActivity {
    TextView btn, forgetpassword, admin;
    Button Login;
    private static final int RC_SIGN_IN = 1;
    private FirebaseAuth mAuth;
    private FirebaseFirestore fstore;
    private ProgressDialog mLoadingdialogue;
    private EditText inputpassword, inputemail;
    int info = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        fetchloginingo();
        inputemail = findViewById(R.id.inputEmail);
        forgetpassword = findViewById(R.id.forgotPassword);
        fstore = FirebaseFirestore.getInstance();
        admin = findViewById(R.id.admin);
        inputpassword = findViewById(R.id.inputPassword);
        mAuth = FirebaseAuth.getInstance();
        mLoadingdialogue = new ProgressDialog(LoginActivity.this);
        Login = findViewById(R.id.btnlogin);
        admin.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), AdminLogin.class)));
        btn = findViewById(R.id.textViewSignUp);
        btn.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, RegistrationActivity.class)));

        Login.setOnClickListener(v -> CheckCrediential());


        forgetpassword.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, Passwordreset.class);
            startActivity(intent);
        });
    }



    private void CheckCrediential() {
        String email = inputemail.getText().toString();
        String password = inputpassword.getText().toString();

        if (email.isEmpty() || !email.contains("@gmail.com")) {
            showError(inputemail, "Email is not valid ");
        } else if (password.isEmpty() || password.length() < 8) {
            showError(inputpassword, "Password must be 8 characters");
        } else {
            mLoadingdialogue.setTitle("Login");
            mLoadingdialogue.setMessage("Please Wait While Validating your Crediential");
            mLoadingdialogue.setCanceledOnTouchOutside(false);
            mLoadingdialogue.show();

            mAuth.signInWithEmailAndPassword(email, password).addOnSuccessListener(authResult -> {
                mLoadingdialogue.dismiss();
                checkuserAccesslevel(authResult.getUser().getUid());


            }).addOnFailureListener(e -> {
                mLoadingdialogue.dismiss();
                Intent intent = new Intent(LoginActivity.this, LoginActivity.class);
                startActivity(intent);
                Toast.makeText(LoginActivity.this, "Incorrect username or password", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void checkuserAccesslevel(String uid) {
        DocumentReference df = fstore.collection("users").document(uid);
        df.get().addOnSuccessListener(documentSnapshot -> {
            if (documentSnapshot.getString("isAdmin") != null) {
                infologin(1);
                Intent intent = new Intent(LoginActivity.this, AdminDashboard.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
            if (documentSnapshot.getString("isUser") != null) {
                infologin(3);
                Intent intent = new Intent(LoginActivity.this, StudentDashboard.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
            if (documentSnapshot.getString("isStaff") != null) {
                infologin(2);
                Intent intent = new Intent(LoginActivity.this, Dashboard.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }


    private void showError(EditText input, String s) {
        input.setError(s);
        input.requestFocus();

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mAuth.getCurrentUser() != null) {
            if (info == 1) {
                Intent intent = new Intent(LoginActivity.this, AdminDashboard.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else if (info == 2) {
                Intent intent = new Intent(LoginActivity.this, Dashboard.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else if (info == 3) {
                Intent intent = new Intent(LoginActivity.this, StudentDashboard.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        }
    }

    private void infologin(int info) {
        SharedPreferences sharedPreferences = getSharedPreferences("logininfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("info", info);
        editor.apply();
    }

    private void fetchloginingo() {
        SharedPreferences sharedPreferences = getSharedPreferences("logininfo", Context.MODE_PRIVATE);
        info = sharedPreferences.getInt("info", 0);
    }

}

