package com.ugmobi.university.Admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.ugmobi.university.R;

import java.util.HashMap;
import java.util.Map;

public class AdminRegister extends AppCompatActivity {
    TextView btn;
    Button Register;
    private FirebaseAuth mAuth;
    private FirebaseFirestore fstore;
    private ProgressDialog mLoadingbar;
    private EditText inputusername,inputpassword, inputemail,inputconfirmpassword;
    boolean valid = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_register);

        btn=findViewById(R.id.alreadyHaveAccount);
        inputusername = findViewById(R.id.inputUsername);
        inputemail = findViewById(R.id.inputEmail);
        inputpassword = findViewById(R.id.inputPassword);
        inputconfirmpassword = findViewById(R.id.inputConformPassword);
        mAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();
        Register = findViewById(R.id.btnRegister);


        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkField(inputusername);
                checkField(inputemail);
                checkField(inputpassword);
                checkField(inputconfirmpassword);



                if (valid){
                    mAuth.createUserWithEmailAndPassword(inputemail.getText().toString(),inputpassword.getText().toString())
                            .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(AdminRegister.this, "Admin Account Created", Toast.LENGTH_SHORT).show();
                             DocumentReference df = fstore.collection("users").document(user.getUid());

                            Map<String,Object> userinfo = new HashMap<>();
                            userinfo.put("Name",inputusername.getText().toString());
                            userinfo.put("UserEmail",inputemail.getText().toString());
                            userinfo.put("isAdmin","1");

                            df.set(userinfo);

                            startActivity(new Intent(getApplicationContext(),AdminDashboard.class));
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(AdminRegister.this, "Fail to create Account", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        });
    }

    private boolean checkField(EditText inputfield) {

        if (inputfield.getText().toString().isEmpty()){
            inputfield.setError("This Field Cannot be empty");
            valid = false;

        }else {
            valid = true;
        }

        return valid;

    }
}