package com.ugmobi.university.Attendence;

public class ClassItem {
    private String className;
    private String subjectname;
    private String id;
    private String uid;

    public ClassItem() {
    }

    public ClassItem(String cid , String className, String subjectname,String id,String uid) {
        this.cid = cid;
        this.className = className;
        this.subjectname = subjectname;
        this.id = id;
        this.uid = uid;

    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    private String cid;

    public String getId() {
        return id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getSubjectname() {
        return subjectname;
    }

    public void setSubjectname(String subjectname) {
        this.subjectname = subjectname;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }
}
