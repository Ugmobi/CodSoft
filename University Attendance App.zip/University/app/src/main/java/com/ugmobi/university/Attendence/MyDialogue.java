package com.ugmobi.university.Attendence;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.ugmobi.university.R;


public class MyDialogue extends DialogFragment {
    public static final String CLASS_ADD_DIALOG = "addClass";
    public static final String STUDENT_ADD_DIALOG = "addstudent";
    public static final String CLASS_UPDATE_DIALOG = "classupdate";
    public static final String STUDENT_UPDATE_DIALOG = "studentupdate";
    onClickListner listner;
    private int roll;
    private String name;

    public MyDialogue(int roll,String name) {
        this.roll = roll;
        this.name = name;
    }

    public MyDialogue() {

    }


    public interface onClickListner {
        void onClick(String text1, String text2);
    }

    public void setListner(onClickListner listner) {
        this.listner = listner;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = null;
        if (getTag().equals(CLASS_ADD_DIALOG)) dialog = getAddClassDialog();
        if (getTag().equals(STUDENT_ADD_DIALOG)) dialog = getAddStudentDialogue();
        if (getTag().equals(CLASS_UPDATE_DIALOG)) dialog = getUpdateClass();
        if (getTag().equals(STUDENT_UPDATE_DIALOG)) dialog = getUpdateStudent();

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return dialog;
    }

    private Dialog getUpdateStudent() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialogue, null);
        builder.setView(view);
        TextView title = view.findViewById(R.id.titleDialogue);
        title.setText("Update Student");

        final EditText rollno_edt = view.findViewById(R.id.edit01);
        final EditText name_edt = view.findViewById(R.id.edit02);


        rollno_edt.setHint("Roll no");
        name_edt.setHint("Student Name");

        Button cancelbtn = view.findViewById(R.id.cancel);
        Button addbtn = view.findViewById(R.id.add_btn);
        addbtn.setText("Update");
        rollno_edt.setText(roll + "");
        rollno_edt.setEnabled(false);
        cancelbtn.setOnClickListener(v -> dismiss());

        addbtn.setOnClickListener(v -> {
            String roll = rollno_edt.getText().toString();
            String name = name_edt.getText().toString();

            listner.onClick(roll, name);
            dismiss();

        });

        return builder.create();
    }

    private Dialog getUpdateClass() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialogue, null);
        builder.setView(view);
        TextView title = view.findViewById(R.id.titleDialogue);
        title.setText("Update Class");

        final EditText class_edt = view.findViewById(R.id.edit01);
        final EditText subject_edt = view.findViewById(R.id.edit02);

        class_edt.setHint("Update Class Name");
        subject_edt.setHint("Update Subject Name");
        Button cancelbtn = view.findViewById(R.id.cancel);
        Button addbtn = view.findViewById(R.id.add_btn);
        addbtn.setText("Update");

        cancelbtn.setOnClickListener(v -> dismiss());

        addbtn.setOnClickListener(v -> {
            String className = class_edt.getText().toString();
            String subName = subject_edt.getText().toString();
            listner.onClick(className, subName);
            dismiss();
        });

        return builder.create();

    }

    private Dialog getAddStudentDialogue() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.addstudentdialogue, null);
        builder.setView(view);
        builder.setCancelable(true);

        final EditText startrollno = view.findViewById(R.id.rollno);
        final EditText endrollno = view.findViewById(R.id.name);


        startrollno.setHint("Roll No");
        endrollno.setHint("Name");

        Button addbtn = view.findViewById(R.id.addbutton);


        addbtn.setOnClickListener(v -> {
            int s;
            String name;
            s = Integer.parseInt(startrollno.getText().toString());
            name = endrollno.getText().toString();

            if (startrollno.getText().toString().length() > 0 || startrollno.getText().toString().length() > 1) {
                listner.onClick(String.valueOf(s), name);
            }
        });

        return builder.create();
    }

    private Dialog getAddClassDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialogue, null);
        builder.setView(view);
        TextView title = view.findViewById(R.id.titleDialogue);
        title.setText("Add New Class");

        final EditText class_edt = view.findViewById(R.id.edit01);
        final EditText subject_edt = view.findViewById(R.id.edit02);

        class_edt.setHint("Department Name With Sem");
        subject_edt.setHint("Subject Name");
        Button cancelbtn = view.findViewById(R.id.cancel);
        Button addbtn = view.findViewById(R.id.add_btn);

        cancelbtn.setOnClickListener(v -> dismiss());

        addbtn.setOnClickListener(v -> {
            if (class_edt.getText().toString().length() > 0 || subject_edt.getText().toString().length() > 0) {
                String className = class_edt.getText().toString();
                String subName = subject_edt.getText().toString();
                listner.onClick(className, subName);
                dismiss();
            } else {
                Toast.makeText(getContext(), "Plz Fill Details", Toast.LENGTH_SHORT).show();
            }
        });

        return builder.create();
    }


}
