package com.ugmobi.university.Attendence;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.ugmobi.university.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AttendenceMain extends AppCompatActivity {
    FloatingActionButton btnadd;
    RecyclerView recyclerView;
    ClassAdapter classAdapter;
    FirebaseFirestore firebaseFirestore;
    RecyclerView.LayoutManager layoutManager;
    ArrayList<ClassItem> classItems = new ArrayList<>();
    DbHelper dbHelper;
    FirebaseAuth mAuth;
    String id = UUID.randomUUID().toString();
    String path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendence_main);
        dbHelper = new DbHelper(this);
        recyclerView = findViewById(R.id.recycleview);
        mAuth = FirebaseAuth.getInstance();
        path = mAuth.getCurrentUser().getUid();
        btnadd = findViewById(R.id.addbutton);
        btnadd.setOnClickListener(v -> showdialogue());

        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        classAdapter = new ClassAdapter(this, classItems);
        recyclerView.setAdapter(classAdapter);

        classAdapter.setOnItemClickListner(AttendenceMain.this::gotoItemActivity);
        // loadData();
        LoadfirebaseDtat();

    }


    private void gotoItemActivity(int position) {
        Intent intent = new Intent(this, StudentActivity.class);
        intent.putExtra("className", classItems.get(position).getClassName());
        intent.putExtra("subjectName", classItems.get(position).getSubjectname());
        intent.putExtra("position", position);
        intent.putExtra("cidd", classItems.get(position).getCid());
        startActivity(intent);
    }

    private void showdialogue() {
        MyDialogue dialogue = new MyDialogue();
        dialogue.show(getSupportFragmentManager(), MyDialogue.CLASS_ADD_DIALOG);
        dialogue.setListner(AttendenceMain.this::addClass);
    }

    private void addClass(String className, String subjectName) {
        long cid = dbHelper.addClass(className, subjectName);
        if (!String.valueOf(cid).equals("-1")) {
            ClassItem classItem = new ClassItem(String.valueOf(cid), className, subjectName, id, path);
            classItems.add(classItem);
            Map<String, String> items = new HashMap<>();
            items.put("cid", String.valueOf(cid));
            items.put("id", id);
            items.put("className", className);
            items.put("subjectname", subjectName);
            items.put("uid", mAuth.getCurrentUser().getUid());
            firebaseFirestore = FirebaseFirestore.getInstance();
            mAuth = FirebaseAuth.getInstance();
            firebaseFirestore.collection(mAuth.getCurrentUser().getUid()).document(id).set(items)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                classItems.clear();
                                LoadfirebaseDtat();
                            }
                        }
                    });

            classAdapter.notifyDataSetChanged();
        } else {
            Toast.makeText(AttendenceMain.this, "Opps Something Went Wrong", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case 0:
                showUpdateDialog(item.getGroupId());
                break;
            case 1:
                deleteClass(item.getGroupId());
                break;
        }
        return super.onContextItemSelected(item);
    }

    private void showUpdateDialog(int position) {
        MyDialogue dialogue = new MyDialogue();
        dialogue.show(getSupportFragmentManager(), MyDialogue.CLASS_UPDATE_DIALOG);
        dialogue.setListner((className, subjectName) -> AttendenceMain.this.updateClass(position, className, subjectName, classItems.get(position).getId()));
    }

    private void updateClass(int position, String className, String subjectName, String idd) {
        dbHelper.updateClass(Long.parseLong(classItems.get(position).getCid()), className, subjectName);
        classItems.get(position).setClassName(className);
        classItems.get(position).setSubjectname(subjectName);
        firebaseFirestore.collection(mAuth.getCurrentUser().getUid())
                .document(idd).update("className", className, "subjectname", subjectName)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(AttendenceMain.this, "Updated..", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(AttendenceMain.this, "Fail To Update..", Toast.LENGTH_SHORT).show());
        classAdapter.notifyItemChanged(position);
    }

    private void deleteClass(int position) {
        int pos = position;
        if (position != -1) {
            firebaseFirestore.collection(mAuth.getCurrentUser().getUid())
                    .document(classItems.get(position).getId()).delete()
                    .addOnCompleteListener(task -> {
                        try {
                            dbHelper.deleteClass(Long.parseLong(classItems.get(pos).getCid()));
                            classItems.remove(pos);
                            classAdapter.notifyItemRemoved(pos);
                        } catch (IndexOutOfBoundsException e) {
                            e.printStackTrace();
                        }
                    }).addOnFailureListener(e -> Toast.makeText(AttendenceMain.this, "Opps Fail To delete", Toast.LENGTH_SHORT).show());
            if (path != null) {
                FirebaseDatabase.getInstance().getReference(path)
                        .child(classItems.get(position).getSubjectname())
                        .removeValue()
                        .addOnSuccessListener(unused -> {

                        }).addOnFailureListener(e -> Toast.makeText(AttendenceMain.this, "Fail to Remove", Toast.LENGTH_SHORT).show());

            }
        }
        classAdapter.notifyDataSetChanged();

    }

    private void LoadfirebaseDtat() {
        firebaseFirestore = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null) {
            firebaseFirestore.collection(mAuth.getCurrentUser().getUid())
                    .addSnapshotListener((value, error) -> {
                        if (value != null) {
                            for (DocumentChange dc : value.getDocumentChanges()) {
                                if (dc.getType() == DocumentChange.Type.ADDED) {
                                    classItems.add(dc.getDocument().toObject(ClassItem.class));
                                }
                                classAdapter.notifyDataSetChanged();
                            }
                        }
                    });
        }
    }

}