package com.ugmobi.university.Attendence;

public class StudentItem {
    private String sid;
    private String roll;
    private String status;
    private String name;

    private boolean selected;

    public StudentItem() {
    }

    public StudentItem(String sid , String roll, String name,String Status) {
        this.sid = sid;
        this.roll = roll;
        this.name = name;
        this.status = Status;
        //status = "";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoll() {
        return roll;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }
}
