package com.ugmobi.university.Staf;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.ugmobi.university.R;

import java.util.HashMap;
import java.util.Map;

public class registration extends AppCompatActivity {
    Button Register;
    private FirebaseAuth mAuth;
    private FirebaseFirestore fstore;
    private EditText inputusername, inputpassword, inputemail, inputconfirmpassword;
    boolean valid = true;
    ProgressBar progressbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_registration);
        inputusername = findViewById(R.id.username);
        inputemail = findViewById(R.id.staffEmail);
        inputpassword = findViewById(R.id.staffpassword);
        progressbar = findViewById(R.id.progressbar);
        inputconfirmpassword = findViewById(R.id.staffconfirmpassword);
        mAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();
        Register = findViewById(R.id.Register);
        Register.setOnClickListener(v -> {
            checkField(inputusername);
            checkField(inputemail);
            checkField(inputpassword);
            checkField(inputconfirmpassword);
            if (valid) {
                progressbar.setVisibility(View.VISIBLE);
                mAuth.createUserWithEmailAndPassword(inputemail.getText().toString(), inputpassword.getText().toString())
                        .addOnSuccessListener(authResult -> {
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(registration.this, "Staff Account Created", Toast.LENGTH_SHORT).show();
                            DocumentReference df = fstore.collection("users").document(user.getUid());
                            Map<String, Object> userinfo = new HashMap<>();
                            userinfo.put("name", inputusername.getText().toString());
                            userinfo.put("isStaff", "1");
                            df.set(userinfo);
                            progressbar.setVisibility(View.GONE);
                            finish();
                        }).addOnFailureListener(e -> {
                            Toast.makeText(registration.this, "Fail to create Account", Toast.LENGTH_SHORT).show();
                            progressbar.setVisibility(View.GONE);
                        });
            }
        });
    }

    private boolean checkField(EditText inputfield) {
        if (inputfield.getText().toString().isEmpty()) {
            inputfield.setError("This Field Cannot be empty");
            valid = false;
        } else {
            valid = true;
        }
        return valid;
    }
}