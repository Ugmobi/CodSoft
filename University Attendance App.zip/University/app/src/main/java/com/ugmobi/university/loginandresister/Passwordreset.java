package com.ugmobi.university.loginandresister;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.transition.TransitionManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.ugmobi.university.R;

public class Passwordreset extends AppCompatActivity {
    private EditText regiesteredemail;
    private Button Resetpasswordbutton;
    private TextView goBack;
    private FrameLayout parentframelayout;
    private ViewGroup emailIconContainer;
    private ImageView emailIcon;
    private TextView emailIconText;
    private ProgressBar progressBar;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passwordreset);

        regiesteredemail = findViewById(R.id.forgotpasswordemail);
        Resetpasswordbutton = findViewById(R.id.resetpasswordbutton);
        goBack = findViewById(R.id.forgot_password_goback_tv);
        firebaseAuth = FirebaseAuth.getInstance();
        emailIconContainer = findViewById(R.id.forgot_password_email_icon_container);
        emailIcon = findViewById(R.id.forgot_password_email_icon);
        emailIconText = findViewById(R.id.forgotpassword_email_icon_text);
        progressBar = findViewById(R.id.forgot_password_progressbar);


        regiesteredemail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkinputs();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent = new Intent(Passwordreset.this,LoginActivity.class);
               startActivity(intent);
            }
        });


        Resetpasswordbutton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                TransitionManager.beginDelayedTransition(emailIconContainer);
                emailIconText.setVisibility(View.GONE);
                Resetpasswordbutton.setEnabled(false);
                Resetpasswordbutton.setTextColor(Color.argb(50,255,255,255));
                TransitionManager.beginDelayedTransition(emailIconContainer);
                emailIcon.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.VISIBLE);

                firebaseAuth.sendPasswordResetEmail(regiesteredemail.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    ScaleAnimation scaleAnimation = new ScaleAnimation(1,0,1,1,emailIcon.getWidth()/2,emailIcon.getHeight()/2);
                                    scaleAnimation.setDuration(100);
                                    scaleAnimation.setInterpolator(new AccelerateInterpolator());
                                    scaleAnimation.setRepeatCount(1);
                                    scaleAnimation.setAnimationListener(new Animation.AnimationListener() {
                                        @Override
                                        public void onAnimationStart(Animation animation) {

                                        }

                                        @Override
                                        public void onAnimationEnd(Animation animation) {
                                            emailIconText.setTextColor(getResources().getColor(R.color.successGreen));
                                            TransitionManager.beginDelayedTransition(emailIconContainer);
                                            emailIconText.setVisibility(View.VISIBLE);
                                            Resetpasswordbutton.setEnabled(false);
                                        }

                                        @Override
                                        public void onAnimationRepeat(Animation animation) {
                                            emailIcon.setImageResource(R.drawable.greenemail);
                                        }
                                    });

                                    emailIcon.startAnimation(scaleAnimation);

                                }else {
                                    String error = task.getException().getMessage();
                                    progressBar.setVisibility(View.GONE);
                                    emailIconText.setText(error);
                                    emailIconText.setTextColor(getResources().getColor(R.color.colorPrimary));
                                    TransitionManager.beginDelayedTransition(emailIconContainer);
                                    emailIconText.setVisibility(View.VISIBLE);
                                }
                                Resetpasswordbutton.setEnabled(true);
                                progressBar.setVisibility(View.GONE);
                                Resetpasswordbutton.setTextColor(getResources().getColor(R.color.colorAcent));
                            }
                        });
            }
        });

    }

    private void checkinputs() {
        if (TextUtils.isEmpty(regiesteredemail.getText().toString())){

            Resetpasswordbutton.setEnabled(false);
            regiesteredemail.setError("plz Provide Email ID");
            Resetpasswordbutton.setTextColor(Color.argb(50,255,255,255));
        }else {
            Resetpasswordbutton.setEnabled(true);
            Resetpasswordbutton.setTextColor(getResources().getColor(R.color.colorAcent));
        }
    }

}