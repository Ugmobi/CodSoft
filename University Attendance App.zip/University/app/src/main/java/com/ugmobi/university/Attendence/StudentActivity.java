package com.ugmobi.university.Attendence;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.ugmobi.university.R;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import me.ibrahimsn.lib.OnItemSelectedListener;
import me.ibrahimsn.lib.SmoothBottomBar;


public class StudentActivity extends AppCompatActivity implements CallBackItemTouch {

    Toolbar toolbar;
    private String className;
    private String subjectName;
    private SmoothBottomBar bottomBar;
    private int position;
    private RecyclerView recyclerView;
    private StudentAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<StudentItem> studentItems = new ArrayList<>();
    private DbHelper dbHelper;
    private String cid;
    private MyCalander calander;
    private TextView subtitle;
    private DatabaseReference database;
    private FirebaseAuth mAuth;
    private RelativeLayout layout;
    private String path;
    private static int REQUEST_CODE_SELECT_FILE = 2;
    DateFormat dateFormat;
    String newDateStr;
    Date datee;
    DatePicker datePicker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        calander = new MyCalander();
        dbHelper = new DbHelper(this);
        Intent intent = getIntent();
        className = intent.getStringExtra("className");
        subjectName = intent.getStringExtra("subjectName");
        position = intent.getIntExtra("position", -1);
        cid = intent.getStringExtra("cidd");
        savecidinsharepref(Integer.parseInt(cid), className, subjectName);
        bottomBar = findViewById(R.id.smoothBottomBar);
        mAuth = FirebaseAuth.getInstance();
        path = mAuth.getCurrentUser().getUid();
        layout = findViewById(R.id.layout);
        recyclerView = findViewById(R.id.studentrecycleview);
        String date = calander.getDate();
        String setdate = "";
        if (date.contains(".")) {
            setdate = date.replace(".", "_");
        }
        database = FirebaseDatabase.getInstance().getReference(mAuth.getCurrentUser().getUid())
                .child(subjectName)
                .child(setdate);

        loadonlinedata();
        dateFormat = new SimpleDateFormat("dd_MM_yyyy");
        datee = new Date();
        newDateStr = dateFormat.format(datee);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new StudentAdapter(this, studentItems);
        recyclerView.setAdapter(adapter);
        ItemTouchHelper.Callback callback = new MyItemTouchHelperCallBack(this);
        ItemTouchHelper touchHelper = new ItemTouchHelper(callback);
        touchHelper.attachToRecyclerView(recyclerView);
        adapter.setOnItemClickListner(StudentActivity.this::changeStatus);


        bottomBar.setOnItemSelectedListener((OnItemSelectedListener) i -> {
            switch (i) {

                case 1:
                    showAddStudentDialog();
                    break;

                case 2:
                    openSheetList();
                    break;

            }
            return false;
        });

        setToolbar();
        // loadData();
        // loadStatusData();
    }

    private void loadonlinedata() {
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                studentItems.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    StudentItem studen = dataSnapshot.getValue(StudentItem.class);
                    studentItems.add(studen);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

   /* @SuppressLint("Range")
    private void loadData() {
        Cursor cursor = dbHelper.getStudentTable(Integer.parseInt(cid));
        studentItems.clear();
        while (cursor.moveToNext()) {
            long sid = cursor.getLong(cursor.getColumnIndex(DbHelper.S_ID));
            int roll = cursor.getInt(cursor.getColumnIndex(DbHelper.STUDENT_ROLL_KEY));
            String name = cursor.getString(cursor.getColumnIndex(DbHelper.STUDENT_NAME));
            studentItems.add(new StudentItem(Long.parseLong(String.valueOf(sid)), roll, name));
        }
        cursor.close();
    }

    */

    private void changeStatus(int position) {
        try {
            String status = studentItems.get(position).getStatus();
            if (status.equals("P")) status = "A";
            else status = "P";
            studentItems.get(position).setStatus(status);
            adapter.notifyItemChanged(position);
        } catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
        }
    }

    private void setToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        TextView title = toolbar.findViewById(R.id.title_toolbar);
        subtitle = toolbar.findViewById(R.id.subtitle_toolbar);
        ImageButton back = findViewById(R.id.back);
        ImageButton save = findViewById(R.id.save);

        save.setOnClickListener(v -> saveStatus());

        title.setText(className);
        subtitle.setText(subjectName + " : " + calander.getDate());

        back.setOnClickListener(v -> StudentActivity.this.onBackPressed());


    }

    private void saveStatus() {
        String date = calander.getDate();
        String replace = "";
        if (date.contains(".")) {
            replace = date.replace(".", "_");
        }
        if (newDateStr.equals(replace)) {
            for (StudentItem studentItem : studentItems) {
                String status = studentItem.getStatus();
                if (!status.equals("A")) {
                    status = "P";
                    Map<String, Object> map = new HashMap<>();
                    map.put("status", "P");
                    mAuth = FirebaseAuth.getInstance();
                    String path = mAuth.getCurrentUser().getUid();
                    String date1 = calander.getDate();
                    String replace1 = "";
                    if (date.contains(".")) {
                        replace1 = date1.replace(".", "_");
                    }

                    FirebaseDatabase.getInstance().getReference(path)
                            .child(subjectName)
                            .child(replace1)
                            .child(studentItem.getSid())
                            .updateChildren(map)
                            .addOnCompleteListener(task -> {

                            }).addOnFailureListener(e -> Toast.makeText(StudentActivity.this, "Fail To Update...", Toast.LENGTH_SHORT).show());

                }
                if (!status.equals("P")) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("status", "A");
                    mAuth = FirebaseAuth.getInstance();
                    String path = mAuth.getCurrentUser().getUid();
                    String date2 = calander.getDate();
                    String replace2 = "";
                    if (date.contains(".")) {
                        replace2 = date2.replace(".", "_");
                    }
                    FirebaseDatabase.getInstance().getReference(path)
                            .child(subjectName)
                            .child(replace2)
                            .child(studentItem.getSid())
                            .updateChildren(map)
                            .addOnCompleteListener(task -> {

                            }).addOnFailureListener(e -> Toast.makeText(StudentActivity.this, "Fail To Update...", Toast.LENGTH_SHORT).show());
                }

                long value = dbHelper.addStatus(Long.parseLong(studentItem.getSid()), Integer.parseInt(cid), calander.getDate(), status);
                if (value == -1)
                    dbHelper.updateStatus(Long.parseLong(studentItem.getSid()), calander.getDate(), status);

            }
            Toast.makeText(StudentActivity.this, "Saved", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(StudentActivity.this, "Date Not Matches", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadStatusData() {
        try {
            for (StudentItem studentItem : studentItems) {
                String status = dbHelper.getStatus(Long.parseLong(studentItem.getSid()), calander.getDate());
                if (status != null) {
                    studentItem.setStatus(status);
                } else studentItem.setStatus("");
            }
            adapter.notifyDataSetChanged();
        }catch (IndexOutOfBoundsException e){
            e.printStackTrace();
        }
    }


    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case 0:
                showUpdateStudentDialog(item.getGroupId());
                break;
            case 1:
                deleteStudent(item.getGroupId());
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.student_menu, menu);

        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
           /* case R.id.addstudent:
                showAddStudentDialog();
                break;
            case R.id.show_calander:
                showCalander();
                break;
            case R.id.import_csvfile:
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("text/comma-separated-values");
                startActivityForResult(intent, REQUEST_CODE_SELECT_FILE);
                break;

            */


        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SELECT_FILE && resultCode == RESULT_OK) {
            if (data != null) {
                Uri selectfileuri = Uri.parse(data.getData().getPath());
                File file = new File(selectfileuri.getPath());
                try {

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void openSheetList() {
        long[] idArray = new long[studentItems.size()];
        int[] rollArray = new int[studentItems.size()];
        String[] nameArray = new String[studentItems.size()];

        for (int i = 0; i < idArray.length; i++)
            idArray[i] = Long.parseLong(studentItems.get(i).getSid());

        for (int i = 0; i < rollArray.length; i++)
            rollArray[i] = Integer.parseInt(studentItems.get(i).getRoll());

        for (int i = 0; i < nameArray.length; i++) {
            nameArray[i] = studentItems.get(i).getName();
        }
        Intent intent = new Intent(StudentActivity.this, SheetListActivity.class);
        intent.putExtra("cid", cid);
        intent.putExtra("idArray", idArray);
        intent.putExtra("rollArray", rollArray);
        intent.putExtra("nameArray", nameArray);
        startActivity(intent);
    }

    private void showCalander() {
        calander.show(getSupportFragmentManager(), "");
        calander.setOnCalanderOkClickListner(this::onCalanderOkListner);
    }

    private void onCalanderOkListner(int year, int month, int day) {
        calander.setDate(year, month, day);
        subtitle.setText(subjectName + " : " + calander.getDate());
        loadStatusData();
    }

    private void showAddStudentDialog() {
        MyDialogue dialogue = new MyDialogue();
        dialogue.show(getSupportFragmentManager(), MyDialogue.STUDENT_ADD_DIALOG);
        dialogue.setListner(this::addStudent);
    }


    private void addStudent(String roll_string, String name) {
        int roll = Integer.parseInt(roll_string);
        long sid = dbHelper.addStudent(Integer.parseInt(cid), roll, name);
        StudentItem studentItem = new StudentItem(String.valueOf(sid), String.valueOf(roll), name, "");
        studentItems.add(studentItem);
        if (sid != -1) {
            Map<String, Object> map = new HashMap<>();
            map.put("roll", roll_string);
            map.put("name", name);
            map.put("sid", String.valueOf(sid));
            map.put("status", "");
            mAuth = FirebaseAuth.getInstance();
            String date = calander.getDate();
            String replace = "";
            if (date.contains(".")) {
                replace = date.replace(".", "_");
            }
            if (path != null) {
                FirebaseDatabase.getInstance().getReference(path)
                        .child(subjectName)
                        .child(replace)
                        .child(String.valueOf(sid))
                        .setValue(map)
                        .addOnCompleteListener(task -> {

                        }).addOnFailureListener(e -> Toast.makeText(StudentActivity.this, "Fail To Insert..", Toast.LENGTH_SHORT).show());
            }
        }

        adapter.notifyDataSetChanged();
    }


    private void showUpdateStudentDialog(int position) {
        MyDialogue dialogue = new MyDialogue(Integer.parseInt(studentItems.get(position).getRoll()), studentItems.get(position).getName());
        dialogue.show(getSupportFragmentManager(), MyDialogue.STUDENT_UPDATE_DIALOG);
        dialogue.setListner((roll_string, name) -> StudentActivity.this.updateStudent(position, name));
    }

    private void updateStudent(int position, String name) {
        dbHelper.updateStudent(Long.parseLong(studentItems.get(position).getSid()), name);
        String date = calander.getDate();
        String replace = "";
        if (date.contains(".")) {
            replace = date.replace(".", "_");
        }
        if (path != null) {
            Map<String, Object> map = new HashMap<>();
            map.put("name", name);
            FirebaseDatabase.getInstance().getReference(path)
                    .child(subjectName)
                    .child(replace)
                    .child(studentItems.get(position).getSid())
                    .updateChildren(map)
                    .addOnCompleteListener(task -> Toast.makeText(StudentActivity.this, "Updated..", Toast.LENGTH_SHORT).show()).addOnFailureListener(e -> Toast.makeText(StudentActivity.this, "Fail To Update...", Toast.LENGTH_SHORT).show());
        }
        adapter.notifyItemChanged(position);
    }

    private void deleteStudent(int position) {
        String date = calander.getDate();
        String replace = "";
        if (date.contains(".")) {
            replace = date.replace(".", "_");
        }
        if (path != null) {
            FirebaseDatabase.getInstance().getReference(path)
                    .child(subjectName)
                    .child(replace)
                    .child(studentItems.get(position).getSid())
                    .removeValue()
                    .addOnSuccessListener(unused -> {
                        try {
                            dbHelper.deleteStudent(String.valueOf(Long.parseLong(studentItems.get(position).getSid())));
                            studentItems.remove(position);
                            adapter.notifyItemRemoved(position);
                            Toast.makeText(StudentActivity.this, "Deleted...", Toast.LENGTH_SHORT).show();
                        } catch (IndexOutOfBoundsException e) {
                            e.printStackTrace();
                        }
                    }).addOnFailureListener(e -> Toast.makeText(StudentActivity.this, "Fail to Remove", Toast.LENGTH_SHORT).show());
        }
        adapter.notifyDataSetChanged();

    }

    public void savecidinsharepref(Integer Target, String classnmae, String subjec) {
        SharedPreferences sharedPref = getApplication().getSharedPreferences("targetlistshow", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("search", Target);
        editor.putString("subject", subjec);
        editor.putString("department", classnmae);
        editor.apply();

    }

    @Override
    public void itemTouchOnMove(int oldPosition, int newPosition) {
        studentItems.add(newPosition, studentItems.remove(oldPosition));
        adapter.notifyItemMoved(oldPosition, newPosition);

    }

    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int position) {

        int rollno = Integer.parseInt(studentItems.get(viewHolder.getAdapterPosition()).getRoll());
        final StudentItem deleteItem = studentItems.get(viewHolder.getAdapterPosition());
        final int deletedIndex = viewHolder.getAdapterPosition();
        dbHelper.deleteStudent(String.valueOf(Long.parseLong(studentItems.get(position).getSid())));
        String date = calander.getDate();
        String replace = "";
        if (date.contains(".")) {
            replace = date.replace(".", "_");
        }
        if (path != null) {
            FirebaseDatabase.getInstance().getReference(path)
                    .child(subjectName)
                    .child(replace)
                    .child(studentItems.get(position).getSid())
                    .removeValue()
                    .addOnSuccessListener(unused -> Toast.makeText(StudentActivity.this, "Deleted...", Toast.LENGTH_SHORT).show()).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(StudentActivity.this, "Fail to Remove", Toast.LENGTH_SHORT).show();
                }
            });
        }
        adapter.remoItem(viewHolder.getAdapterPosition());
        Snackbar snackbar = Snackbar.make(layout, rollno + " Removed..!", Snackbar.LENGTH_LONG);
        snackbar.setAction("UNDO", view -> {
            adapter.restoreItem(deleteItem, deletedIndex);
            int roll = Integer.parseInt(studentItems.get(position).getRoll());
            long sid = dbHelper.addStudent(Integer.parseInt(cid), roll, studentItems.get(position).getName());
            StudentItem studentItem = new StudentItem(String.valueOf(sid), String.valueOf(roll), studentItems.get(position).getName(), "");
            studentItems.add(studentItem);
            if (sid != -1) {
                Map<String, Object> map = new HashMap<>();
                map.put("roll", studentItems.get(position).getRoll());
                map.put("name", studentItems.get(position).getName());
                map.put("sid", String.valueOf(sid));
                map.put("status", studentItems.get(position).getStatus());
                mAuth = FirebaseAuth.getInstance();
                String date1 = calander.getDate();
                String replace1 = "";
                if (date1.contains(".")) {
                    replace1 = date1.replace(".", "_");
                }
                if (path != null) {
                    FirebaseDatabase.getInstance().getReference(path)
                            .child(subjectName)
                            .child(replace1)
                            .child(String.valueOf(sid))
                            .setValue(map)
                            .addOnCompleteListener(task -> {

                            }).addOnFailureListener(e -> Toast.makeText(StudentActivity.this, "Fail To Insert..", Toast.LENGTH_SHORT).show());
                }
            }
        });
        snackbar.setActionTextColor(Color.GREEN);
        snackbar.show();
    }
}