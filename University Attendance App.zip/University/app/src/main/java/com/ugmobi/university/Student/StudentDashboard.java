package com.ugmobi.university.Student;



import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.ugmobi.university.Attendence.AttendenceMain;
import com.ugmobi.university.R;
import com.ugmobi.university.loginandresister.LoginActivity;

import java.util.Objects;

public class StudentDashboard extends AppCompatActivity {
    FirebaseAuth mAuth;
    TextView profile;
    FirebaseFirestore fstore;
    String uid;
    Button signout,attendance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);
        mAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();
        profile = findViewById(R.id.profilename);
        signout = findViewById(R.id.Logout);
        attendance = findViewById(R.id.attendance);

        attendance.setOnClickListener(view -> startActivity(new Intent(StudentDashboard.this, AttendenceMain.class)));
        signout.setOnClickListener(view -> {
            mAuth.signOut();
            infologin(0);
            startActivity(new Intent(StudentDashboard.this, LoginActivity.class));

        });
        if (mAuth.getCurrentUser() !=null){
            uid = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();

            DocumentReference df = fstore.collection("users").document(uid);
            df.addSnapshotListener(this, (value, error) -> profile.setText(String.format("Hi, %s", Objects.requireNonNull(value).getString("name"))));
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mAuth.getCurrentUser() == null) {
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }
    }
    private void infologin(int info) {
        SharedPreferences sharedPreferences = getSharedPreferences("logininfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("info", info);
        editor.apply();
    }
}
