package com.ugmobi.university.loginandresister;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.ugmobi.university.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class RegistrationActivity extends AppCompatActivity {
    TextView btn;
    Button Register;
    Spinner spinner;
    String[] year;
    private FirebaseAuth mAuth;
    private FirebaseFirestore fstore;
    private ProgressDialog mLoadingbar;
    private EditText inputusername, inputpassword, inputemail, inputconfirmpassword;
    ArrayAdapter<String> adapter1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        btn = findViewById(R.id.alreadyHaveAccount);
        spinner = findViewById(R.id.selectyear);
        inputusername = findViewById(R.id.inputUsername);
        inputemail = findViewById(R.id.inputEmail);

        inputpassword = findViewById(R.id.inputPassword);
        year = new String[]{"select", "1 Year", "2 Year", "3 Year"};
        adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, year);
        spinner.setAdapter(adapter1);
        fstore = FirebaseFirestore.getInstance();
        inputconfirmpassword = findViewById(R.id.inputConformPassword);
        mAuth = FirebaseAuth.getInstance();
        mLoadingbar = new ProgressDialog(RegistrationActivity.this);
        Register = findViewById(R.id.btnRegister);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckCrediential();
            }
        });


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
            }
        });

    }

    private void CheckCrediential() {
        String username = inputusername.getText().toString();
        String email = inputemail.getText().toString();
        String password = inputpassword.getText().toString();
        String conformpassword = inputconfirmpassword.getText().toString();

        if (username.isEmpty() || username.length() < 7) {
            showError(inputusername, "Your username is not valid");
        } else if (email.isEmpty() || !email.contains("@gmail.com")) {
            showError(inputemail, "Email is not valid ");
        } else if (password.isEmpty() || password.length() < 8) {
            showError(inputpassword, "Password must be 8 characters");
        } else if (conformpassword.isEmpty() && conformpassword.equals(password)) {
            showError(inputconfirmpassword, "Password not match!");
        } else {
            mLoadingbar.setTitle("Registration");
            mLoadingbar.setMessage("Please Wait Registration in Process");
            mLoadingbar.setCanceledOnTouchOutside(false);
            mLoadingbar.show();

            mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        mLoadingbar.dismiss();
                        FirebaseUser user = mAuth.getCurrentUser();
                        DocumentReference df = fstore.collection("users").document(user.getUid());
                        Map<String, Object> userinfo = new HashMap<>();
                        userinfo.put(spinner.getSelectedItem().toString(), "1");
                        userinfo.put("name", inputusername.getText().toString());
                        userinfo.put("isUser", "1");

                        df.set(userinfo);
                        Toast.makeText(RegistrationActivity.this, "Registration Successfull", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    mLoadingbar.dismiss();
                    Dialog dialog;
                    dialog = new Dialog(RegistrationActivity.this);
                    dialog.setContentView(R.layout.update_fail_dialogue);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                    dialog.setCancelable(false);
                    dialog.setCanceledOnTouchOutside(false);
                    Button cancel = dialog.findViewById(R.id.btn_cancel);
                    LottieAnimationView lottieAnimationView;
                    lottieAnimationView = dialog.findViewById(R.id.imageView);
                    lottieAnimationView.playAnimation();
                    cancel.setOnClickListener(view -> dialog.dismiss());
                    dialog.show();
                }
            });
        }


    }

    private void showError(EditText input, String s) {
        input.setError(s);
        input.requestFocus();

    }
}