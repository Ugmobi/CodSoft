package com.ugmobi.university.Admin;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.ugmobi.university.R;

public class AdminLogin extends AppCompatActivity {


    FirebaseAuth mAuth;
    FirebaseFirestore fstore;
    EditText email, password;
    Button login;
    boolean valid = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        mAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();
        email = findViewById(R.id.inputEmail);
        password = findViewById(R.id.inputPassword);
        login = findViewById(R.id.btnlogin);

        login.setOnClickListener(v -> {

            checkField(email);
            checkField(password);
            if (valid){
                mAuth.signInWithEmailAndPassword(email.getText().toString(),password.getText().toString())
                        .addOnSuccessListener(authResult -> checkuserAccesslevel(authResult.getUser().getUid())).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AdminLogin.this, ""+e, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void checkuserAccesslevel(String uid) {

        DocumentReference df = fstore.collection("users").document(uid);
        df.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                Log.d("TAG","onSuccess: "+ documentSnapshot.getData());
                if (documentSnapshot.getString("isAdmin") != null){
                    Toast.makeText(AdminLogin.this, "Login As Admin", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(),AdminDashboard.class));
                    finish();
                }

                if (documentSnapshot.getString("isUser")!= null){
                    Toast.makeText(AdminLogin.this, "Access Denied", Toast.LENGTH_SHORT).show();
                    Dialog dialog;

                    dialog = new Dialog(AdminLogin.this);
                    dialog.setContentView(R.layout.accessdeniedialogue);
                    dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.dialoguebackgrounabout));
                    dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
                    dialog.setCancelable(true);
                    dialog.getWindow().getAttributes().windowAnimations = R.style.animation;

                    dialog.show();
                }

                if (documentSnapshot.getString("isStaff")!= null){
                    Toast.makeText(AdminLogin.this, "Access Denied", Toast.LENGTH_SHORT).show();
                    Dialog dialog;

                    dialog = new Dialog(AdminLogin.this);
                    dialog.setContentView(R.layout.accessdeniedialogue2);
                    dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.dialoguebackgrounabout));
                    dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
                    dialog.setCancelable(true);
                    dialog.getWindow().getAttributes().windowAnimations = R.style.animation;

                    dialog.show();
                }

            }
        });
    }

    private boolean checkField(EditText inputfield) {

        if (inputfield.getText().toString().isEmpty()){
            inputfield.setError("This Field Cannot be empty");
            valid = false;

        }else {
            valid = true;
        }

        return valid;

    }
}