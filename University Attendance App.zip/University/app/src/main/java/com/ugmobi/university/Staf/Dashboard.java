package com.ugmobi.university.Staf;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.ugmobi.university.Attendence.AttendenceMain;
import com.ugmobi.university.R;
import com.ugmobi.university.loginandresister.LoginActivity;

public class Dashboard extends AppCompatActivity {
    Button attendance, logout,keyshowbtn;
    TextView textView;
    private FirebaseAuth mAuth;
    private FirebaseFirestore fstore;
    String dname;
    Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_dashboard);
        textView = findViewById(R.id.profilename);
        attendance = findViewById(R.id.attendance);
        logout = findViewById(R.id.Logout);
        keyshowbtn = findViewById(R.id.keyshowbtn);
        keyshowbtn.setOnClickListener(view -> {
            dialog = new Dialog(Dashboard.this);
            dialog.setContentView(R.layout.access_token_show);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);
            Button cancel = dialog.findViewById(R.id.btn_cancel);
            ImageButton copy = dialog.findViewById(R.id.copybtn);
            TextView accesskey = dialog.findViewById(R.id.accesskey);
            accesskey.setText(mAuth.getCurrentUser().getUid());
            copy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("Access Key",accesskey.getText().toString());
                    clipboard.setPrimaryClip(clip);
                    Snackbar snackbar = Snackbar.make(view, " Copied..!", Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            });
            LottieAnimationView lottieAnimationView;
            lottieAnimationView = dialog.findViewById(R.id.imageView);
            lottieAnimationView.playAnimation();
            cancel.setOnClickListener(view2 -> dialog.dismiss());
            dialog.getWindow().setWindowAnimations(R.style.DialogAnimation);
            dialog.show();
        });
        logout.setOnClickListener(view -> {
            mAuth.signOut();
            infologin(0);
            if (mAuth.getCurrentUser() == null) {
                Intent intent = new Intent(Dashboard.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        mAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();
        if (mAuth.getCurrentUser() !=null){
            String uid = mAuth.getCurrentUser().getUid();
            DocumentReference df = fstore.collection("users").document(uid);
            df.get().addOnSuccessListener(documentSnapshot -> {
                dname = documentSnapshot.getString("name");
                if (dname != null) {
                    textView.setText("Hi, " + dname);
                }
            }).addOnFailureListener(e -> Toast.makeText(Dashboard.this, "Fail to Fetch Data", Toast.LENGTH_SHORT).show());
        }

        attendance.setOnClickListener(v -> startActivity(new Intent(Dashboard.this, AttendenceMain.class)));

    }
    private void infologin(int info) {
        SharedPreferences sharedPreferences = getSharedPreferences("logininfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("info", info);
        editor.apply();
    }
}